<?php
// "Comeback": a learner's open mistakes, worked out from their own answers (no extra table, so past results are never touched).
//
// A mistake is a task answered wrongly. It is fixed when the learner later answers a similar task (same grammar point since 16 November, same topic, level within
// one step, thinking level within one step, same construction for used to) correctly: a different sentence. The same task right again never fixes it
// (teacher, 23 November: that is memory; until then it counted on a later day). A task answered wrongly again after it was fixed becomes a mistake again.
// Placement mistakes above the level the test found are PARKED: they are not offered for Second Chance until the learner
// practises that level (they mark the edge of the level, not a gap to fix first).
// A fixed mistake is LOCKED IN when the learner answers another, different task of the same kind correctly on a later day.
// A wrong answer on the same kind of task after that opens it again ("reopened").

final class Mistakes
{
    public const DAYS = 45;       // older mistakes are let go
    private const SCAN_LIMIT = 3000;

    /**
     * @param array<int,string> $plLevels level found by a placement session that has no saved report yet (session id => level)
     * @return array{open: array<string,array>, parked: array<string,array>, fixed: int, locked: int, reopened: int} open mistakes in the order they were made; parked ones; how many were fixed, locked in, or opened again
     */
    public static function scan(int $uid, array $plLevels = []): array
    {
        $rows = Db::all('SELECT item_id, skill, level, bloom, correct, answer, created_at, for_item, psession_id FROM attempts WHERE user_id = ? AND created_at > ? ORDER BY id ASC LIMIT ' . self::SCAN_LIMIT, [$uid, time() - self::DAYS * 86400]);
        $open = [];
        $solid = [];      // fixed, not yet locked in: id => kind of task, the day it was fixed, the tasks that fixed it
        $fixed = $locked = $reopened = 0;
        $corrected = Reports::correctedIds();
        foreach ($rows as $r) {
            $id = $r['item_id'];
            $task = Content::item($id);
            if (!$task || Content::role($task) === 'learn') continue;
            // A valid alternative simple form is correct English, but not evidence of the continuous construction.
            if ((int) $r['correct'] && !self::demonstratesTarget($task, $r['answer'] ?? '')) continue;
            $day = date('Y-m-d', (int) $r['created_at']);
            if (!(int) $r['correct'] && isset($corrected[$id])) continue;   // rule C: a mistake on a task that was faulty and has been corrected
            if (!(int) $r['correct']) {
                if (!isset($open[$id])) $open[$id] = ['item_id' => $id, 'skill' => $r['skill'], 'level' => $r['level'], 'bloom' => (int) $r['bloom'], 'tries' => 0, 'day' => $day, 'ses' => (int) $r['psession_id']];
                $open[$id]['tries']++;
                $open[$id]['day'] = $day;
                foreach ($solid as $sid => $sv) {
                    if (self::similar($sv, $r)) { unset($solid[$sid]); $reopened++; }
                }
                continue;
            }
            if (isset($open[$id])) {   // the same sentence right again, on any day: a repeat that helps to remember, not yet fixed (teacher, 23 November, option A:
                $open[$id]['retried'] = true;   // a mistake is fixed only by a different task of the same grammar point)
                continue;
            }
            // Second Chance knows which mistake the task stood for: that one is fixed
            $for = $r['for_item'] ?? null;
            if ($for !== null && isset($open[$for]) && self::similar($open[$for], $r)) {
                $m = $open[$for];
                $solid[$for] = ['item_id' => $for, 'skill' => $m['skill'], 'level' => $m['level'], 'bloom' => $m['bloom'], 'day' => $day, 'items' => [$id => 1]];
                unset($open[$for]); $fixed++;
                continue;
            }
            // a right answer fixes the open mistake it is closest to (same level and thinking level first; the oldest of equals)
            $best = null; $bestD = 99;
            foreach ($open as $mid => $m) {
                if (!self::similar($m, $r)) continue;
                $dist = abs(self::levelIdx($m['level']) - self::levelIdx($r['level'])) + abs((int) $m['bloom'] - (int) $r['bloom']);
                if ($dist < $bestD) { $bestD = $dist; $best = $mid; }
            }
            if ($best !== null) {
                $m = $open[$best];
                $solid[$best] = ['item_id' => $best, 'skill' => $m['skill'], 'level' => $m['level'], 'bloom' => $m['bloom'], 'day' => $day, 'items' => [$id => 1]];
                unset($open[$best]); $fixed++;
                continue;
            }
            foreach ($solid as $sid => $sv) {
                if (!self::similar($sv, $r)) continue;
                if ($sv['day'] !== $day && !isset($sv['items'][$id])) { unset($solid[$sid]); $locked++; break; }
                // A successful repeat is not new transfer evidence, but do not ask it again immediately.
                $solid[$sid]['checked_day'] = $day;
            }
        }
        // tasks the teacher has paused (reported as flawed) are not the learner's mistakes
        foreach (array_keys(Reports::pausedIds()) as $pid) unset($open[$pid]);
        $parked = [];
        if ($open) {
            $pl = $plLevels;   // placement sessions and the level each found
            foreach (Db::all("SELECT id, state FROM psessions WHERE user_id = ? AND mode = 'placement'", [$uid]) as $p) {
                if (isset($pl[(int) $p['id']])) continue;
                $pl[(int) $p['id']] = json_decode((string) $p['state'], true)['report']['overall_level'] ?? '';   // also a test not finished
            }
            if ($pl) {   // a level-test mistake waits until the learner has practised that topic at least once (teacher, 12 November, A)
                $practised = [];   // topics practised outside a placement test
                foreach (Db::all("SELECT DISTINCT a.skill FROM attempts a JOIN psessions s ON s.id = a.psession_id WHERE a.user_id = ? AND s.mode <> 'placement'", [$uid]) as $r) $practised[$r['skill']] = true;
                foreach ($open as $id => $m) {
                    if (!isset($pl[$m['ses']])) continue;
                    if (empty($practised[$m['skill']])) { $parked[$id] = $m; unset($open[$id]); }
                }
            }
        }
        return ['open' => $open, 'parked' => $parked, 'solid' => $solid, 'fixed' => $fixed, 'locked' => $locked, 'reopened' => $reopened];
    }

    /** Accepted past-perfect-simple alternatives do not establish the continuous form. */
    public static function demonstratesTarget(array $task, $answer): bool
    {
        if (($task['skill'] ?? '') !== 'narrative_b2' || ($task['kind'] ?? '') !== 'gap') return true;
        $given = is_array($answer) ? $answer : json_decode((string) $answer, true);
        if (!is_array($given)) $given = [(string) $answer];
        foreach ($task['answers'] ?? [] as $n => $options) {
            if (preg_match('/\bhad been\s+\w+ing\b/i', $options[0] ?? '')
                && !preg_match('/\bhad been\s+\w+ing\b/i', (string) ($given[$n] ?? ''))) return false;
        }
        return true;
    }

    private static function levelIdx(string $level): int
    {
        $i = array_search($level, array_keys(Content::BASE), true);
        return $i === false ? 0 : (int) $i;
    }

    private static function similar(array $m, array $r): bool
    {
        $a = Content::item($m['item_id']); $b = Content::item($r['item_id']);
        return self::sameConstruction($a, $b)
            && self::samePoint($a, $b)
            && $m['skill'] === $r['skill']
            && abs(self::levelIdx($m['level']) - self::levelIdx($r['level'])) <= 1
            && abs((int) $m['bloom'] - (int) $r['bloom']) <= 1;
    }

    /** A mistake is fixed only by a task of the same grammar point (teacher, 16 November, after a tester's report: a mistake with
     *  'good at' was fixed by 'answer my question'). Tasks without a point on the map keep the old rule (same topic). */
    public static function samePoint(?array $a, ?array $b): bool
    {
        if (!$a || !$b) return false;
        $pa = Content::point($a); $pb = Content::point($b);
        return $pa === null || $pb === null || $pa === $pb;
    }

    /** Unknown or mixed constructions cannot stand in for one specific rule. */
    public static function sameConstruction(?array $a, ?array $b): bool
    {
        if (!$a || !$b || $a['skill'] !== $b['skill']) return false;
        if ($a['skill'] !== 'used_to') return true;
        $ka = self::construction($a); $kb = self::construction($b);
        return $ka !== null && $ka === $kb;
    }

    private static function construction(array $it): ?string
    {
        $s = $it['sentence'] ?? $it['q'];
        if ($it['kind'] === 'text') $s = $it['answers'][0][0] ?? '';
        elseif ($it['kind'] === 'mcq') $s = str_contains($s, '___') ? str_replace('___', $it['correct'], $s) : $it['correct'];
        elseif ($it['kind'] === 'gap') foreach ($it['answers'] as $blank) $s = preg_replace('/___/', $blank[0], $s, 1);
        $s = strtolower(str_replace(['’', '*'], ["'", ''], $s));
        $s = str_replace("n't", ' not', $s);
        $accustomed = preg_match("/\b(?:am|is|are|was|were|be|been|get|gets|got|getting)(?: not)? used to\b|(?:'m|'s|'re) used to\b/", $s);
        $rest = preg_replace("/\b(?:am|is|are|was|were|be|been|get|gets|got|getting)(?: not)? used to\b|(?:'m|'s|'re) used to\b/", '', $s);
        $habit = preg_match('/\bused? to\b/', $rest);
        if ($habit && $accustomed) return null;
        return $accustomed ? 'accustomed' : ($habit ? 'past_habit' : null);
    }

    /**
     * Fixed mistakes due for a check: fixed 2 or more days ago and not yet locked in, the oldest first (spaced review; teacher's
     * decision 27 October: only 7% of fixed mistakes were ever locked in). @return string[] mistake ids
     */
    public static function reviewDue(int $uid, ?array $scan = null): array
    {
        $scan = $scan ?? self::scan($uid);
        $limit = date('Y-m-d', time() - 2 * 86400);
        $due = array_filter($scan['solid'], fn($v, $id) => ($v['checked_day'] ?? $v['day']) <= $limit && Content::item((string) $id), ARRAY_FILTER_USE_BOTH);
        uasort($due, fn($a, $b) => strcmp($a['day'], $b['day']));
        return array_map('strval', array_keys($due));
    }

    /** Open mistakes in a good teaching order: oldest first, but different topics take turns. @return string[] item ids */
    public static function queue(int $uid, int $max = 10): array
    {
        $by = [];
        foreach (self::scan($uid)['open'] as $id => $m) {
            if (Content::item($id)) $by[$m['skill']][] = $id;
        }
        $out = [];
        while ($by && count($out) < $max) {
            foreach ($by as $s => &$list) {
                $out[] = array_shift($list);
                if (!$list) unset($by[$s]);
                if (count($out) >= $max) break;
            }
            unset($list);
        }
        return $out;
    }

    /**
     * A different task that trains the same thing as a mistake: same topic, close level and thinking level. Null when there is none.
     * $code: prefer tasks for this kind of mistake. $maxScaffold / $minScaffold: prefer tasks with at most / at least this much
     * independence (Content::scaffold), so an easier task follows a miss and the same support comes back later.
     */
    public static function twin(int $uid, string $mistakeId, array $exclude, bool $angle = false, ?array $levels = null, ?string $code = null, ?int $maxScaffold = null, ?int $minScaffold = null, ?string $point = null): ?array
    {
        $m = Content::item($mistakeId);
        if (!$m) return null;
        // the grammar map (14 November, C2): first a task of the same point (been / gone after been / gone, not any present perfect task);
        // only when the point has no other task does the old choice by topic apply
        if ($point !== null) {
            $same = self::twinPick($uid, $m, $mistakeId, $exclude, $angle, $levels, $code, $maxScaffold, $minScaffold, $point);
            if ($same) return $same;
        }
        return self::twinPick($uid, $m, $mistakeId, $exclude, $angle, $levels, $code, $maxScaffold, $minScaffold, null);
    }

    /** Second Chance (teacher, 16 November): the most similar task of the same grammar point (same kind of task first), or null. */
    public static function twinOfPoint(int $uid, string $mistakeId, array $exclude, string $point): ?array
    {
        $m = Content::item($mistakeId);
        return $m ? self::twinPick($uid, $m, $mistakeId, $exclude, false, null, null, null, null, $point) : null;
    }

    /** The task of the same kind of mistake with the lowest cost; $only = a grammar point the task must have. */
    private static function twinPick(int $uid, array $m, string $mistakeId, array $exclude, bool $angle, ?array $levels, ?string $code, ?int $maxScaffold, ?int $minScaffold, ?string $only): ?array
    {
        $paused = Reports::pausedIds();
        $seen = [];
        foreach (Db::all('SELECT item_id, COUNT(1) AS c FROM attempts WHERE user_id = ? GROUP BY item_id', [$uid]) as $r) $seen[$r['item_id']] = (int) $r['c'];
        $best = null;
        $bestCost = PHP_FLOAT_MAX;
        foreach (Content::items() as $it) {
            if ($it['skill'] !== $m['skill'] || $it['id'] === $mistakeId || isset($exclude[$it['id']]) || isset($paused[$it['id']])) continue;
            if (abs(self::levelIdx($it['level']) - self::levelIdx($m['level'])) > 1 || abs($it['bloom'] - $m['bloom']) > 1) continue;
            if (!self::sameConstruction($m, $it) || Content::role($it) === 'learn') continue;
            if ($levels && !in_array($it['level'], $levels, true)) continue;
            if ($it['kind'] === 'write' && $m['kind'] !== 'write') continue;   // open writing never stands in for a short task
            if ($only !== null && Content::point($it) !== $only) continue;
            $cost = (isset($seen[$it['id']]) ? 0.8 * min(3, $seen[$it['id']]) : 0)
                + ($angle ? ($it['kind'] === $m['kind'] ? 0.3 : 0) : ($it['kind'] === $m['kind'] ? 0 : 0.3)) + abs($it['bloom'] - $m['bloom']) * 0.2 + random_int(0, 30) / 100;
            if ($code !== null && !in_array($code, $it['err'] ?? [], true)) $cost += 0.6;
            // the check after a mistake tests the same rule, not a harder or longer sentence with new words (Cowork test, 26 October)
            if (self::levelIdx($it['level']) > self::levelIdx($m['level'])) $cost += 0.8;
            if (mb_strlen(self::text($it)) > 1.3 * mb_strlen(self::text($m)) + 10) $cost += 0.5;
            $sc = Content::scaffold($it);
            if ($maxScaffold !== null && $sc > $maxScaffold) $cost += 1.0 * ($sc - $maxScaffold);
            if ($minScaffold !== null && $sc < $minScaffold) $cost += 1.0 * ($minScaffold - $sc);
            if ($cost < $bestCost) { $bestCost = $cost; $best = $it; }
        }
        return $best;
    }

    /**
     * After a second wrong answer in one grammar point (14 November, C2): one task from a point it stands on (its "needs" in the map)
     * that has tasks at the learner's level or below. A task that needs the form (not a learning task), not open writing, not seen
     * in this session; the first prerequisite in the map's order is preferred, then a task the learner has met least. Null if none.
     */
    public static function needsTask(int $uid, string $point, array $exclude, string $maxLevel): ?array
    {
        $p = Content::mapPoint($point);
        if (!$p) return null;
        $paused = Reports::pausedIds();
        $seen = [];
        foreach (Db::all('SELECT item_id, COUNT(1) AS c FROM attempts WHERE user_id = ? GROUP BY item_id', [$uid]) as $r) $seen[$r['item_id']] = (int) $r['c'];
        // a C1 point first gives an easier task of the SAME point (teacher, 23 November: after *criteria*, not an A2 task about luggage)
        if (strncmp((string) ($p['level'] ?? ''), 'C1', 2) === 0) {
            $best = null; $bestCost = PHP_FLOAT_MAX;
            foreach (Content::items() as $it) {
                if (Content::point($it) !== $point || isset($exclude[$it['id']]) || isset($paused[$it['id']]) || $it['kind'] === 'write') continue;
                $cost = (int) $it['bloom'] + (isset($seen[$it['id']]) ? 2 * min(3, $seen[$it['id']]) : 0) + random_int(0, 30) / 100;
                if ($cost < $bestCost) { $bestCost = $cost; $best = $it; }
            }
            if ($best) return $best;
        }
        if (!$p['needs']) return null;
        $order = array_flip($p['needs']);
        $best = null; $bestCost = PHP_FLOAT_MAX;
        foreach (Content::items() as $it) {
            $pt = Content::point($it);
            if ($pt === null || !isset($order[$pt]) || isset($exclude[$it['id']]) || isset($paused[$it['id']])) continue;
            if (self::levelIdx($it['level']) > self::levelIdx($maxLevel) || Content::role($it) === 'learn' || $it['kind'] === 'write' || !empty($it['practice_only'])) continue;
            $cost = $order[$pt] * 0.5 + (isset($seen[$it['id']]) ? 0.8 * min(3, $seen[$it['id']]) : 0) + random_int(0, 30) / 100;
            if ($cost < $bestCost) { $bestCost = $cost; $best = $it; }
        }
        return $best;
    }

    /** The words a learner has to read in a task (instruction and sentence), to compare how long two tasks are. */
    private static function text(array $it): string
    {
        return $it['q'] . ' ' . ($it['correct'] ?? '') . ' ' . ($it['sentence'] ?? '');
    }

    /** What the teacher can see of how the "slip or gap" probes and the mistake life-cycle work, in numbers only (no names). */
    public static function evidence(): array
    {
        $probe = ['first_probes' => 0, 'slips' => 0, 'gaps' => 0, 'angle_probes' => 0, 'angle_right' => 0];
        $topics = [];
        foreach (Db::all("SELECT state FROM psessions WHERE state LIKE '%probe_log%'") as $r) {
            $st = json_decode($r['state'], true);
            foreach ($st['probe_log'] ?? [] as $p) {
                if (($p['stage'] ?? 1) === 1) {
                    $probe['first_probes']++; if ($p['ok']) $probe['slips']++; else $probe['gaps']++;
                    $it = Content::item((string) ($p['for'] ?? ''));
                    if ($it) { $topics[$it['skill']]['probes'] = ($topics[$it['skill']]['probes'] ?? 0) + 1; if (!$p['ok']) $topics[$it['skill']]['gaps'] = ($topics[$it['skill']]['gaps'] ?? 0) + 1; }
                }
                else { $probe['angle_probes']++; if ($p['ok']) $probe['angle_right']++; }
            }
        }
        $life = ['learners' => 0, 'open' => 0, 'fixed' => 0, 'locked' => 0, 'reopened' => 0];
        foreach (Db::all("SELECT DISTINCT a.user_id AS id FROM attempts a JOIN users u ON u.id = a.user_id WHERE u.role = 'student' AND u.is_test = 0 AND a.created_at > ?", [time() - self::DAYS * 86400]) as $u) {
            $m = self::scan((int) $u['id']);
            $life['learners']++;
            $life['open'] += count($m['open']);
            $life['fixed'] += $m['fixed']; $life['locked'] += $m['locked']; $life['reopened'] += $m['reopened'];
        }
        $list = [];
        foreach ($topics as $sid => $t) { $sk = Content::skill($sid); $list[] = ['id' => $sid, 'label' => $sk ? $sk['label'] : $sid, 'probes' => (int) $t['probes'], 'gaps' => (int) ($t['gaps'] ?? 0)]; }
        usort($list, fn($a, $b) => [$b['gaps'], $b['probes']] <=> [$a['gaps'], $a['probes']]);
        return ['probes' => $probe, 'mistakes' => $life, 'topics' => array_slice($list, 0, 8)];
    }
}
