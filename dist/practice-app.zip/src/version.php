<?php
return ['version' => '2026-11-03 23:59'];
