<?php
// Loads the question bank (content/items.json, content/meta.json).

final class Content
{
    private static ?array $items = null;
    private static ?array $meta = null;
    private static ?array $byId = null;
    private static ?array $retired = null;
    private static array $hidden = [];

    public const BASE = ['A2.1' => 1.0, 'A2.2' => 2.0, 'B1.1' => 3.0, 'B1.2' => 4.0, 'B2.1' => 5.0, 'B2.2' => 6.0, 'C1.1' => 7.0, 'C1.2' => 8.0];

    /** content/<name>.php (production, never downloadable) or content/<name>.json (development). */
    private static function load(string $name): array
    {
        $php = __DIR__ . '/../content/' . $name . '.php';
        if (is_file($php)) return require $php;
        return json_decode(file_get_contents(__DIR__ . '/../content/' . $name . '.json'), true);
    }

    public static function items(): array
    {
        if (self::$items === null) {
            self::$items = self::load('items');
            if (class_exists('CustomItems', false)) self::$items = array_merge(self::$items, CustomItems::approved()); // tasks the teacher added and approved
            self::hideRelabelled();
            self::$byId = [];
            foreach (self::$items as $i => $it) {
                self::$items[$i]['d'] = self::difficulty($it['level'], $it['bloom']);
                self::$items[$i]['scaffold'] = self::scaffold($it);
                self::$items[$i]['err'] = self::errors($it);
                self::$byId[$it['id']] = &self::$items[$i];
            }
        }
        return self::$items;
    }

    /** Built-in tasks that were given a lower level as a copy (content/relabelled.php): ids => true. */
    public static function relabelled(): array
    {
        static $ids = null;
        if ($ids === null) {
            $f = __DIR__ . '/../content/relabelled.php';
            $ids = is_file($f) ? array_fill_keys(require $f, true) : [];
        }
        return $ids;
    }

    /**
     * A task that was relabelled (for example B1 to A2) leaves the active pool as soon as its approved copy exists at the lower level.
     * The original stays readable, so every old answer and unfinished session keeps working.
     */
    private static function hideRelabelled(): void
    {
        $rel = self::relabelled();
        if (!$rel || !class_exists('CustomItems', false)) return;
        $copies = [];
        foreach (CustomItems::approved() as $c) if (strpos($c['level'], 'A2') === 0) $copies[$c['skill'] . '|' . mb_strtolower($c['q'])] = true;
        if (!$copies) return;
        $keep = [];
        foreach (self::$items as $it) {
            if (isset($rel[$it['id']]) && isset($copies[$it['skill'] . '|' . mb_strtolower($it['q'])])) {
                $it['d'] = self::difficulty($it['level'], $it['bloom']);
                self::$hidden[$it['id']] = $it;
                continue;
            }
            $keep[] = $it;
        }
        self::$items = $keep;
    }


    /**
     * How much support a task gives (teacher's plan, 25 October): a task with less support comes only after the learner has managed
     * one with more. 0 = choose or drag (the answer is on the screen), 1 = type with a clue (a verb in brackets, a named form, word order),
     * 2 = type without a clue, 3 = open writing. A task may set its own value.
     */
    public static function scaffold(array $it): int
    {
        if (isset($it['scaffold'])) return (int) $it['scaffold'];
        switch ($it['kind']) {
            case 'mcq': case 'match': return 0;
            case 'order': return 1;
            case 'gap':
                if (!empty($it['bank'])) return 0;
                return (preg_match('/\([^)]*\)\s*$/u', $it['q']) || preg_match('/^(Use|Complete with|Make|Give)\b/u', $it['q'])) ? 1 : 2;
            case 'text': return 2;
            default: return 3;
        }
    }

    /** The error types a task trains (docs/ERROR-TYPES.md): its own list, else the usual ones of its topic. Never shown to learners. */
    public static function errors(array $it): array
    {
        if (!empty($it['err'])) return array_values((array) $it['err']);
        return self::meta()['skill_err'][$it['skill']] ?? [];
    }

    public static function meta(): array
    {
        return self::$meta ??= self::load('meta');
    }

    /** The topics learners see: only those that have tasks (a topic the teacher adds starts empty until tasks are approved). */
    public static function liveMeta(): array
    {
        $m = self::meta();
        $have = [];
        foreach (self::items() as $it) $have[$it['skill']] = true;
        $m['skills'] = array_values(array_filter($m['skills'], fn($s) => isset($have[$s['id']])));
        $areas = array_flip(array_column($m['skills'], 'area'));
        $m['areas'] = array_values(array_filter($m['areas'], fn($a) => isset($areas[$a['id']])));
        return $m;
    }

    public const FULL_LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];

    /** How many live questions there are per full level (A2, B1 ...), in all and per topic: what the practice picker shows. */
    public static function levelCounts(): array
    {
        $all = array_fill_keys(self::FULL_LEVELS, 0);
        $by = []; $half = [];
        foreach (self::items() as $it) {
            $full = substr($it['level'], 0, 2);
            $all[$full] = ($all[$full] ?? 0) + 1;
            $by[$it['skill']][$full] = ($by[$it['skill']][$full] ?? 0) + 1;
            $half[$it['skill']][$it['level']] = ($half[$it['skill']][$it['level']] ?? 0) + 1;
        }
        return ['all' => $all, 'by_skill' => $by, 'by_half' => $half];
    }

    /** The kind of task a learner sees (teacher, 28 October): recognise = choose or match, use = fill in, word bank, word order, write = typed sentence or open writing. */
    public static function taskCat(?array $it): string
    {
        if (!$it) return 'recognise';
        if (in_array($it['kind'], ['mcq', 'match'], true)) return 'recognise';
        if (in_array($it['kind'], ['text', 'write'], true)) return 'write';
        return 'use';   // gap (typed word or word bank), order
    }
    /** Right / all answers per kind of task, from attempts rows that have item_id and correct. */
    public static function catCounts(array $rows): array
    {
        $out = ['recognise' => ['n' => 0, 'correct' => 0], 'use' => ['n' => 0, 'correct' => 0], 'write' => ['n' => 0, 'correct' => 0]];
        foreach ($rows as $r) { $c = self::taskCat(self::item((string) $r['item_id'])); $out[$c]['n']++; $out[$c]['correct'] += (int) $r['correct']; }
        return $out;
    }

    public static function item(string $id): ?array
    {
        self::items();
        if (isset(self::$byId[$id])) return self::$byId[$id];
        // Historical answers and sessions already in progress keep the exact item
        // they originally used. Retired items never enter items()/pickNext().
        if (self::$retired === null) {
            self::$retired = [];
            foreach (self::load('retired') as $it) {
                $it['d'] = self::difficulty($it['level'], $it['bloom']);
                self::$retired[$it['id']] = $it;
            }
        }
        return self::$retired[$id] ?? self::$hidden[$id] ?? self::customById($id);
    }

    /** The ids of built-in tasks that have a corrected version (retired.json). */
    public static function retiredIds(): array
    {
        return array_column(self::load('retired'), 'id');
    }

    /** A custom task that is not (or no longer) approved: reports and old answers still point at it. */
    private static function customById(string $id): ?array
    {
        if (!class_exists('CustomItems', false)) return null;
        $it = CustomItems::find($id);
        if ($it) $it['d'] = self::difficulty($it['level'], $it['bloom']);
        return $it;
    }

    public static function difficulty(string $level, int $bloom): float
    {
        return self::BASE[$level] + ($bloom - 1) * 0.2;
    }

    public static function levelFromTheta(float $theta, ?array $allowed = null): string
    {
        // boundaries calibrated with simulated learners (tests/sim.py): estimates run slightly low at the top and high at the bottom
        $lv = $theta < 1.8 ? 'A2.1' : ($theta < 2.5 ? 'A2.2' : ($theta < 3.5 ? 'B1.1' : ($theta < 4.5 ? 'B1.2' : ($theta < 5.5 ? 'B2.1' : ($theta < 6.5 ? 'B2.2' : ($theta < 7.5 ? 'C1.1' : 'C1.2'))))));
        if ($allowed) {
            $order = array_keys(self::BASE);
            $idx = array_search($lv, $order);
            $best = $allowed[0];
            foreach ($allowed as $a) {
                if (abs(array_search($a, $order) - $idx) < abs(array_search($best, $order) - $idx)) $best = $a;
            }
            return $best;
        }
        return $lv;
    }

    /** The level for an ability fitted to all answers at once (placement): the boundaries sit halfway between the level bases. */
    /**
     * The level a placement result is given: the highest level whose typical task (thinking level 3, difficulty base + 0.4) the learner
     * gets right at least half of the time (theta >= base + 0.4). Before 25 October the bar was base - 0.5, so a learner who got most
     * tasks of a level wrong could still be given that level (full test report: "about B2" with 3 of 8 B2 questions right).
     */
    public static function levelFromAbility(float $theta): string
    {
        $out = 'A2.1';
        foreach (self::BASE as $lv => $base) {
            if ($lv !== 'A2.1' && $theta >= $base + 0.4) $out = $lv;
        }
        return $out;
    }

    public static function skill(string $id): ?array
    {
        foreach (self::meta()['skills'] as $s) {
            if ($s['id'] === $id) return $s;
        }
        return null;
    }

    /** What the browser may see: no answers. */
    public static function publicItem(array $it, ?int $seed = null): array
    {
        $skill = self::skill($it['skill']);
        $out = [
            'id' => $it['id'], 'kind' => $it['kind'], 'q' => $it['q'], 'bloom' => $it['bloom'],
            'level' => $it['level'], 'skill' => $it['skill'], 'skill_label' => $skill['label'] ?? $it['skill'],
            'area' => $skill['area'] ?? 'active',
        ];
        $seed = ($seed ?? random_int(1, 1 << 30)) ^ crc32($it['id']);
        if ($it['kind'] === 'mcq') {
            $out['options'] = self::shuffled(array_merge([$it['correct']], $it['wrong']), $seed);
        }
        if ($it['kind'] === 'gap') {
            $out['blanks'] = count($it['answers']);
            if (!empty($it['bank'])) $out['bank'] = self::shuffled($it['bank'], $seed);
        }
        if ($it['kind'] === 'order') {
            $out['tokens'] = self::shuffled(array_map(['Grader', 'properCase'], explode(' ', $it['sentence'])), $seed);
        }
        if ($it['kind'] === 'match') {
            $out['lefts'] = array_column($it['pairs'], 0);
            $out['rights'] = self::shuffled(array_column($it['pairs'], 1), $seed);
        }
        return $out;
    }

    /** A repeatable shuffle (the same task shows the same order after a reload). Never returns the original order. */
    private static function shuffled(array $list, int $seed): array
    {
        $orig = array_values($list);
        $a = $orig;
        mt_srand($seed);
        for ($i = count($a) - 1; $i > 0; $i--) {
            $j = mt_rand(0, $i);
            [$a[$i], $a[$j]] = [$a[$j], $a[$i]];
        }
        mt_srand();
        if ($a === $orig && count($a) > 1) $a = array_merge(array_slice($a, 1), [$a[0]]);
        return $a;
    }
}
